DEPLOIEMENT SUR RENDER (3 MINUTES)

1. Va sur https://render.com
2. New + → Web Service
3. Upload ce projet (ZIP)
4. Start command:
   gunicorn app:app
5. Clique Deploy

Ton app sera en ligne.
